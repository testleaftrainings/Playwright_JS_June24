import { SFHomePage } from "./SFHomePage";



export class SFLeads extends SFHomePage{
    
    async verifytoastMeassge(){
        //[text()='']
    }

}
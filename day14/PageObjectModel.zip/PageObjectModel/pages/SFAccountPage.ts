import { SFHomePage } from "./SFHomePage";

export class SalesAccount extends SFHomePage{

}
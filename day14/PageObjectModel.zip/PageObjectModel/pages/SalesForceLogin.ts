import { Page,Locator } from '@playwright/test';
import { PlaywrightWrapper } from '../utility/playwrightWrapper';
import fs from 'fs'

export class SFLogin extends PlaywrightWrapper{

    //page:Page;
    public Locators={
        usernameField:"#username"
    }

    constructor(page:Page){
       super(page)
    }

    async loadUrl(url:string){
            await this.page.goto(url)
    }
    async doLogin(username:string,password:string){    
        await this.typeAndEnter(this.Locators.usernameField,username)
        await this.page.locator("#password").fill(password)
        await this.page.locator("#Login").click();
   }
}
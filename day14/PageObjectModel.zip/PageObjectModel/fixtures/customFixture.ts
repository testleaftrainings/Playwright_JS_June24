
import {test as baseTest} from '@playwright/test'
import { SFLogin } from '../pages/SalesForceLogin'
import { SFHomePage } from '../pages/SFHomePage'
import { SFLeads } from '../pages/SFLeads'

//type inference for the fixture

type AppPageFixture={  //user defined name
   loginPage:SFLogin,
   hpPage:SFHomePage,
   leadsPage:SFLeads
}
export const test =baseTest.extend<AppPageFixture>({
    loginPage :async({page},use)=>{
    const lpPage=new SFLogin(page)
     use(lpPage)  ;    
    },
    hpPage :async({page},use)=>{
        const hpPage=new SFHomePage(page)
     use(hpPage) ;
        },
    })






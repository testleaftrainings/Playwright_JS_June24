
import {test} from '../fixtures/customFixture'
import fs from 'fs'
import { SFLeads } from '../pages/SFLeads';


//const userData=   JSON.parse(fs.readFileSync("./data/locatordata.json" ,'utf-8'))
test(`SalesForce Login with valid data`, async ({loginPage,hpPage}) => {
    await loginPage.loadUrl("https://login.salesforce.com/")
    await loginPage.doLogin("vidyar@testleaf.com", "Sales@123")
    await hpPage.clickAppLauncher();
    await hpPage.clickViewAll()
    await hpPage.searchModule("Leads")
    await hpPage.clickLeadModule();
})
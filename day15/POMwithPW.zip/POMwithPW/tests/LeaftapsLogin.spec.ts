import {test} from "../fixture/mycustomFixture";
import { WelcomePage } from "../pages/welcomePage";
import { LoginPage } from "../pages/loginPage";


test(`Login test Functionality`, async ({ loginPage }) => {  
  await loginPage.verifyPageUrl();
})

